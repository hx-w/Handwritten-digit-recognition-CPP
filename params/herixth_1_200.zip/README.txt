trained             60000
hl_num             1
hl_nodes_num  200
test_num          10000
accuracy           94.9%