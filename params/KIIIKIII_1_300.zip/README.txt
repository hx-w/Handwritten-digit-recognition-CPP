trained             60000
hl_num             1
hl_nodes_num  300
test_num          10000
accuracy           95.36%
